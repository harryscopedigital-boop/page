'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import Image from 'next/image'
import { ExternalLink } from 'lucide-react'

const portfolioItems = [
  {
    title: 'Responsive Website Design',
    category: 'Web Development',
    image: 'https://cdn.abacus.ai/images/231f6f86-8419-4914-b9be-bc52e41b2e0b.png',
  },
  {
    title: 'Mobile App Interface',
    category: 'App Development',
    image: 'https://cdn.abacus.ai/images/061f932f-847e-4710-a52a-3dda22b6954a.png',
  },
  {
    title: 'Brand Identity Design',
    category: 'Graphics Design',
    image: 'https://cdn.abacus.ai/images/a96fe100-8b4e-4493-a09c-c754b2cf33b7.png',
  },
  {
    title: 'Video Production',
    category: 'Video Creation',
    image: 'https://cdn.abacus.ai/images/fc097ce6-45b3-4a43-a6df-c7eb8e3f97f2.png',
  },
  {
    title: 'Web Development Dashboard',
    category: 'Web Development',
    image: 'https://cdn.abacus.ai/images/a49422f6-9ca3-4c96-a493-e5dd7a5fe653.png',
  },
  {
    title: 'Digital Marketing Campaign',
    category: 'Digital Marketing',
    image: 'https://cdn.abacus.ai/images/b376e601-4bd0-4a7f-8217-4b0a74f6b3cd.png',
  },
  {
    title: 'E-commerce Platform',
    category: 'Web Development',
    image: 'https://cdn.abacus.ai/images/25976664-3b04-430b-a3c3-84303dc07d15.png',
  },
  {
    title: 'Corporate Website',
    category: 'Web Development',
    image: 'https://cdn.abacus.ai/images/9110102b-a107-49e9-8534-252e4a8ff84b.png',
  },
]

export default function Portfolio() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.05,
  })

  return (
    <section id="portfolio" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
            Our <span className="text-orange-500">Portfolio</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Showcasing our best work across various digital disciplines
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {portfolioItems?.map?.((item: any, index: number) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2"
            >
              <div className="relative aspect-video bg-gray-200">
                <Image
                  src={item?.image ?? ''}
                  alt={item?.title ?? 'Portfolio item'}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/90 via-blue-900/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-4">
                  <div className="flex items-center space-x-2 text-white">
                    <ExternalLink className="w-5 h-5" />
                    <span className="font-medium">View Project</span>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <span className="text-sm text-orange-500 font-semibold">
                  {item?.category ?? ''}
                </span>
                <h3 className="text-lg font-bold text-blue-900 mt-2">
                  {item?.title ?? ''}
                </h3>
              </div>
            </motion.div>
          )) ?? []}
        </div>
      </div>
    </section>
  )
}
