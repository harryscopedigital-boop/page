'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Star, Quote } from 'lucide-react'
import { useEffect, useState } from 'react'

interface Review {
  author_name: string
  rating: number
  text: string
  time: number
}

export default function Testimonials() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await fetch('/api/google-reviews')
        if (response?.ok) {
          const data = await response?.json()
          setReviews(data?.reviews ?? [])
        }
      } catch (error) {
        console.error('Error fetching reviews:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchReviews()
  }, [])

  // Default testimonials if Google Reviews aren't available
  const defaultTestimonials = [
    {
      author_name: 'John Doe',
      rating: 5,
      text: 'Harryscope Digital Solutions transformed our online presence with a stunning website. Their team is professional, creative, and delivered beyond our expectations!',
      time: Date.now(),
    },
    {
      author_name: 'Sarah Williams',
      rating: 5,
      text: 'Outstanding service! The mobile app they developed for us is intuitive and our customers love it. Highly recommended for any digital project.',
      time: Date.now(),
    },
    {
      author_name: 'Michael Chen',
      rating: 5,
      text: 'The graphics design and branding work exceeded all expectations. They truly understand how to bring a vision to life. A+ service!',
      time: Date.now(),
    },
  ]

  const displayReviews = reviews?.length > 0 ? reviews : defaultTestimonials

  return (
    <section id="testimonials" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
            Client <span className="text-orange-500">Testimonials</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Hear what our satisfied clients have to say about working with us
          </p>
        </motion.div>

        {loading ? (
          <div className="text-center text-gray-500">Loading testimonials...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {displayReviews?.slice?.(0, 3)?.map?.((review: Review, index: number) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gradient-to-br from-gray-50 to-gray-100 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2 relative"
              >
                <Quote className="absolute top-6 right-6 w-12 h-12 text-orange-500/20" />
                <div className="flex items-center space-x-1 mb-4">
                  {Array?.from?.({ length: 5 })?.map?.((_, i: number) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < (review?.rating ?? 0)
                          ? 'text-yellow-400 fill-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  )) ?? []}
                </div>
                <p className="text-gray-700 mb-6 italic leading-relaxed">
                  "{review?.text ?? ''}"
                </p>
                <div>
                  <p className="font-bold text-blue-900">{review?.author_name ?? 'Anonymous'}</p>
                </div>
              </motion.div>
            )) ?? []}
          </div>
        )}
      </div>
    </section>
  )
}
