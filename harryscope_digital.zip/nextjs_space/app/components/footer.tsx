import Image from 'next/image'
import { Facebook, Twitter, Instagram, Linkedin } from 'lucide-react'

export default function Footer() {
  const currentYear = new Date()?.getFullYear?.()

  return (
    <footer className="bg-blue-950 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Logo & Description */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="relative w-12 h-12">
                <Image
                  src="https://cdn.abacus.ai/images/30f1690d-50bb-4f4d-86c3-7d611feeb160.png"
                  alt="Harryscope Digital Solutions Logo"
                  fill
                  className="object-contain"
                />
              </div>
              <span className="font-bold text-xl">
                Harryscope<span className="text-orange-500"> Digital</span>
              </span>
            </div>
            <p className="text-blue-200 text-sm">
              Transforming ideas into exceptional digital experiences
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-blue-200 hover:text-orange-400 transition-colors text-sm">
                  Home
                </a>
              </li>
              <li>
                <a href="#services" className="text-blue-200 hover:text-orange-400 transition-colors text-sm">
                  Services
                </a>
              </li>
              <li>
                <a href="#portfolio" className="text-blue-200 hover:text-orange-400 transition-colors text-sm">
                  Portfolio
                </a>
              </li>
              <li>
                <a href="#contact" className="text-blue-200 hover:text-orange-400 transition-colors text-sm">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="font-bold text-lg mb-4">Connect With Us</h3>
            <div className="flex space-x-4">
              <a
                href="#"
                className="w-10 h-10 bg-blue-800 hover:bg-orange-500 rounded-lg flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-blue-800 hover:bg-orange-500 rounded-lg flex items-center justify-center transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-blue-800 hover:bg-orange-500 rounded-lg flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-blue-800 hover:bg-orange-500 rounded-lg flex items-center justify-center transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-blue-800 pt-8 text-center">
          <p className="text-blue-200 text-sm">
            © {currentYear} Harryscope Digital Solutions. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
