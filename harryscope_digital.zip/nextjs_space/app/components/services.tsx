'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Globe, Smartphone, Palette, Video, BookOpen, TrendingUp } from 'lucide-react'

const services = [
  {
    icon: Globe,
    title: 'Website Design & Development',
    description: 'Custom, responsive websites built with cutting-edge technologies to create stunning online experiences.',
    color: 'from-blue-500 to-blue-700',
  },
  {
    icon: Smartphone,
    title: 'App Development',
    description: 'Native and cross-platform mobile applications designed for seamless user experiences.',
    color: 'from-orange-500 to-red-600',
  },
  {
    icon: Palette,
    title: 'Graphics Design',
    description: 'Eye-catching visual designs that communicate your brand message effectively.',
    color: 'from-purple-500 to-pink-600',
  },
  {
    icon: Video,
    title: 'Video Creation',
    description: 'Professional video production and editing services for engaging multimedia content.',
    color: 'from-green-500 to-teal-600',
  },
  {
    icon: BookOpen,
    title: 'Web Tutorials',
    description: 'Comprehensive training and tutorials to help you master web technologies.',
    color: 'from-indigo-500 to-blue-600',
  },
  {
    icon: TrendingUp,
    title: 'Digital Marketing',
    description: 'Strategic marketing campaigns to boost your online presence and drive conversions.',
    color: 'from-yellow-500 to-orange-600',
  },
]

export default function Services() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
            Our <span className="text-orange-500">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive digital solutions designed to transform your business and accelerate growth
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services?.map?.((service: any, index: number) => {
            const Icon = service?.icon
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group bg-gradient-to-br from-gray-50 to-gray-100 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2"
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${service?.color ?? ''} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg`}>
                  {Icon && <Icon className="w-8 h-8 text-white" />}
                </div>
                <h3 className="text-2xl font-bold text-blue-900 mb-4">
                  {service?.title ?? ''}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {service?.description ?? ''}
                </p>
              </motion.div>
            )
          }) ?? []}
        </div>
      </div>
    </section>
  )
}
