'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Target, Users, Award, Zap } from 'lucide-react'

const features = [
  {
    icon: Target,
    title: 'Strategic Approach',
    description: 'Data-driven strategies tailored to achieve your business goals',
  },
  {
    icon: Users,
    title: 'Expert Team',
    description: 'Skilled professionals dedicated to delivering excellence',
  },
  {
    icon: Award,
    title: 'Quality Results',
    description: 'Premium solutions that exceed expectations every time',
  },
  {
    icon: Zap,
    title: 'Fast Delivery',
    description: 'Efficient workflows ensuring timely project completion',
  },
]

export default function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="about" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
            Empowering Brands Through
            <span className="text-orange-500"> Digital Innovation</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            At Harryscope Digital Solutions, we specialize in crafting exceptional digital experiences that drive growth and elevate brands in the digital landscape.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features?.map?.((feature: any, index: number) => {
            const Icon = feature?.icon
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2 group"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-blue-900 to-orange-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  {Icon && <Icon className="w-8 h-8 text-white" />}
                </div>
                <h3 className="text-xl font-bold text-blue-900 mb-3">
                  {feature?.title ?? ''}
                </h3>
                <p className="text-gray-600">
                  {feature?.description ?? ''}
                </p>
              </motion.div>
            )
          }) ?? []}
        </div>
      </div>
    </section>
  )
}
