'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Menu, X } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const navLinks = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Services', href: '#services' },
  { name: 'Portfolio', href: '#portfolio' },
  { name: 'Testimonials', href: '#testimonials' },
  { name: 'Contact', href: '#contact' },
]

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window?.scrollY > 50)
    }
    window?.addEventListener?.('scroll', handleScroll)
    return () => window?.removeEventListener?.('scroll', handleScroll)
  }, [])

  const scrollToSection = (href: string) => {
    const element = document?.querySelector?.(href)
    element?.scrollIntoView?.({ behavior: 'smooth' })
    setMobileMenuOpen(false)
  }

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <button
              onClick={() => scrollToSection('#home')}
              className="flex items-center space-x-3 focus:outline-none"
              aria-label="Go to home"
            >
              <div className="relative w-12 h-12">
                <Image
                  src="https://cdn.abacus.ai/images/30f1690d-50bb-4f4d-86c3-7d611feeb160.png"
                  alt="Harryscope Digital Solutions Logo"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
              <span className={`font-bold text-xl transition-colors ${
                isScrolled ? 'text-blue-900' : 'text-white'
              }`}>
                Harryscope<span className="text-orange-500"> Digital</span>
              </span>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-1">
              {navLinks?.map?.((link: any) => (
                <button
                  key={link?.href}
                  onClick={() => scrollToSection(link?.href ?? '#')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all hover:bg-orange-500 hover:text-white ${
                    isScrolled ? 'text-gray-700' : 'text-white'
                  }`}
                >
                  {link?.name ?? ''}
                </button>
              )) ?? []}
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`md:hidden p-2 rounded-lg transition-colors ${
                isScrolled ? 'text-gray-700' : 'text-white'
              }`}
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-blue-900/95 backdrop-blur-md md:hidden"
            style={{ marginTop: '80px' }}
          >
            <nav className="flex flex-col items-center justify-center h-full space-y-6">
              {navLinks?.map?.((link: any) => (
                <button
                  key={link?.href}
                  onClick={() => scrollToSection(link?.href ?? '#')}
                  className="text-2xl font-medium text-white hover:text-orange-500 transition-colors"
                >
                  {link?.name ?? ''}
                </button>
              )) ?? []}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
