import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXTAUTH_URL || 'http://localhost:3000'),
  title: 'Harryscope Digital Solutions | Professional Digital Agency',
  description: 'Leading digital agency offering Website Design & Development, App Development, Graphics Design, Video Creation, Web Tutorials, and Digital Marketing services.',
  icons: {
    icon: '/favicon.svg',
    shortcut: '/favicon.svg',
  },
  openGraph: {
    title: 'Harryscope Digital Solutions | Professional Digital Agency',
    description: 'Leading digital agency offering Website Design & Development, App Development, Graphics Design, Video Creation, Web Tutorials, and Digital Marketing services.',
    images: ['/og-image.png'],
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <script src="https://apps.abacus.ai/chatllm/appllm-lib.js"></script>
      </head>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  )
}
