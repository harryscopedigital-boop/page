import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

// Google Places API integration
// Note: This requires a Google Places API key to be set in environment variables
// For now, returns empty array - user can add their API key later

export async function GET() {
  try {
    const apiKey = process.env.GOOGLE_PLACES_API_KEY
    
    if (!apiKey) {
      // Return empty array if no API key configured
      return NextResponse.json({ reviews: [] })
    }

    // First, get the place ID for "Harryscope Digital Solutions"
    const searchUrl = `https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=Harryscope+Digital+Solutions&inputtype=textquery&fields=place_id&key=${apiKey}`
    
    const searchResponse = await fetch(searchUrl)
    const searchData = await searchResponse?.json?.()
    
    if (!searchData?.candidates?.[0]?.place_id) {
      return NextResponse.json({ reviews: [] })
    }

    const placeId = searchData?.candidates?.[0]?.place_id

    // Get place details including reviews
    const detailsUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=reviews&key=${apiKey}`
    
    const detailsResponse = await fetch(detailsUrl)
    const detailsData = await detailsResponse?.json?.()
    
    const reviews = detailsData?.result?.reviews ?? []
    
    return NextResponse.json({ reviews })
  } catch (error: any) {
    console.error('Error fetching Google reviews:', error)
    return NextResponse.json({ reviews: [] })
  }
}
