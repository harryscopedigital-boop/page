import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  try {
    const body = await request?.json?.()
    const { name, email, phone, message } = body ?? {}

    // Validate required fields
    if (!name || !email || !message) {
      return NextResponse.json(
        { success: false, message: 'Name, email, and message are required' },
        { status: 400 }
      )
    }

    // Save to database
    const contactForm = await prisma?.contactForm?.create?.({
      data: {
        name,
        email,
        phone: phone ?? null,
        message,
        status: 'new',
      },
    })

    // Prepare HTML email
    const htmlBody = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f9fafb; padding: 20px;">
        <div style="background: linear-gradient(135deg, #1e3a8a 0%, #f97316 100%); padding: 30px; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">New Contact Form Submission</h1>
        </div>
        <div style="background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
          <h2 style="color: #1e3a8a; border-bottom: 2px solid #f97316; padding-bottom: 10px; margin-bottom: 20px;">
            Contact Details
          </h2>
          <div style="margin: 20px 0;">
            <p style="margin: 10px 0; color: #555;"><strong style="color: #1e3a8a;">Name:</strong> ${name ?? ''}</p>
            <p style="margin: 10px 0; color: #555;"><strong style="color: #1e3a8a;">Email:</strong> <a href="mailto:${email ?? ''}" style="color: #f97316;">${email ?? ''}</a></p>
            ${phone ? `<p style="margin: 10px 0; color: #555;"><strong style="color: #1e3a8a;">Phone:</strong> <a href="tel:${phone}" style="color: #f97316;">${phone}</a></p>` : ''}
          </div>
          <div style="margin-top: 30px;">
            <h3 style="color: #1e3a8a; margin-bottom: 10px;">Message:</h3>
            <div style="background: #f9fafb; padding: 20px; border-radius: 8px; border-left: 4px solid #f97316; color: #333; line-height: 1.6;">
              ${message?.replace?.(/\n/g, '<br>') ?? ''}
            </div>
          </div>
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #666; font-size: 12px;">
            <p style="margin: 5px 0;"><strong>Submission ID:</strong> ${contactForm?.id ?? ''}</p>
            <p style="margin: 5px 0;"><strong>Submitted at:</strong> ${new Date()?.toLocaleString?.() ?? ''}</p>
          </div>
        </div>
        <div style="text-align: center; margin-top: 20px; color: #999; font-size: 12px;">
          <p>This is an automated notification from Harryscope Digital Solutions website</p>
        </div>
      </div>
    `

    // Send email notification
    try {
      const appUrl = process.env.NEXTAUTH_URL ?? ''
      const appName = appUrl ? new URL(appUrl)?.hostname?.split?.('.')?.[0] : 'Harryscope Digital'

      const emailResponse = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          deployment_token: process.env.ABACUSAI_API_KEY,
          app_id: process.env.WEB_APP_ID,
          notification_id: process.env.NOTIF_ID_CONTACT_FORM_SUBMISSION,
          subject: `New Contact Form: ${name ?? 'Unknown'}`,
          body: htmlBody,
          is_html: true,
          recipient_email: 'info@harryscopedigital.com.ng',
          sender_email: `noreply@${appUrl ? new URL(appUrl)?.hostname : 'harryscopedigital.com.ng'}`,
          sender_alias: appName ?? 'Harryscope Digital',
        }),
      })

      const emailResult = await emailResponse?.json?.()
      if (!emailResult?.success && !emailResult?.notification_disabled) {
        console.error('Failed to send email notification:', emailResult?.message)
      }
    } catch (emailError) {
      console.error('Error sending email notification:', emailError)
      // Don't fail the request if email fails
    }

    return NextResponse.json({
      success: true,
      message: 'Thank you for your message! We will get back to you soon.',
    })
  } catch (error: any) {
    console.error('Error processing contact form:', error)
    return NextResponse.json(
      { success: false, message: 'Failed to submit form. Please try again.' },
      { status: 500 }
    )
  }
}
